package com.camel.unittesting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CamelUnitTestingSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
