package com.camel.unittesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelUnitTestingSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(CamelUnitTestingSpringBootApplication.class, args);
	}

}
